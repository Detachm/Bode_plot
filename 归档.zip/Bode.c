#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <complex.h>

#define MAX_N 10  // 假设矩阵最大为10x10，方便调试
#define EPSILON 1e-15

// Gauss-Jordan法求解矩阵

void gauss_jordan(double complex matrix[MAX_N][MAX_N], double complex *b, int n) {
    printf("\n开始 Gauss-Jordan 消元...\n");
    for (int i = 0; i < n; i++) {
        printf("\n-------- 处理第 %d 步 --------\n", i + 1);
        
        // 打印当前矩阵状态
        printf("\n当前矩阵状态:\n");
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                printf("(%6.3f+%6.3fi) ", creal(matrix[r][c]), cimag(matrix[r][c]));
            }
            printf("| (%6.3f+%6.3fi)\n", creal(b[r]), cimag(b[r]));
        }

        // 寻找当前列中绝对值最大的元素作为主元
        int max_row = i;
        double max_val = cabs(matrix[i][i]);
        
        for (int k = i + 1; k < n; k++) {
            if (cabs(matrix[k][i]) > max_val) {
                max_val = cabs(matrix[k][i]);
                max_row = k;
            }
        }
        
        // 如果需要，交换行
        if (max_row != i) {
            printf("\n交换第 %d 行和第 %d 行\n", i + 1, max_row + 1);
            for (int j = 0; j < n; j++) {
                double complex temp = matrix[i][j];
                matrix[i][j] = matrix[max_row][j];
                matrix[max_row][j] = temp;
            }
            double complex temp = b[i];
            b[i] = b[max_row];
            b[max_row] = temp;
            
            // 打印交换后的矩阵
            printf("\n交换后的矩阵:\n");
            for (int r = 0; r < n; r++) {
                for (int c = 0; c < n; c++) {
                    printf("(%6.3f+%6.3fi) ", creal(matrix[r][c]), cimag(matrix[r][c]));
                }
                printf("| (%6.3f+%6.3fi)\n", creal(b[r]), cimag(b[r]));
            }
        }

        // 主元归一化
        double complex pivot = matrix[i][i];
        if (cabs(pivot) < EPSILON) {
            printf("\n警告：主元 (%6.3f+%6.3fi) 接近零，矩阵可能奇异\n", 
                   creal(pivot), cimag(pivot));
            continue;
        }

        printf("\n将第 %d 行主元 (%6.3f+%6.3fi) 归一化\n", i + 1, creal(pivot), cimag(pivot));
        for (int j = 0; j < n; j++) {
            matrix[i][j] /= pivot;
            if (cabs(matrix[i][j]) < EPSILON) {
                matrix[i][j] = 0;
            }
        }
        b[i] /= pivot;

        // 打印归一化后的矩阵
        printf("\n归一化后的矩阵:\n");
        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                printf("(%6.3f+%6.3fi) ", creal(matrix[r][c]), cimag(matrix[r][c]));
            }
            printf("| (%6.3f+%6.3fi)\n", creal(b[r]), cimag(b[r]));
        }

        // 对其他行进行消元
        for (int k = 0; k < n; k++) {
            if (k == i) continue;
            double complex factor = matrix[k][i];
            if (cabs(factor) < EPSILON) continue;  // 如果系数接近零，跳过这一行的消元

            printf("\n消去第 %d 行的第 %d 列元素，系数为 (%6.3f+%6.3fi)\n", 
                   k + 1, i + 1, creal(factor), cimag(factor));
            
            for (int j = 0; j < n; j++) {
                matrix[k][j] -= factor * matrix[i][j];
                if (cabs(matrix[k][j]) < EPSILON) {
                    matrix[k][j] = 0;
                }
            }
            b[k] -= factor * b[i];

            // 打印每一行消元后的结果
            printf("消元后的第 %d 行:\n", k + 1);
            for (int j = 0; j < n; j++) {
                printf("(%6.3f+%6.3fi) ", creal(matrix[k][j]), cimag(matrix[k][j]));
            }
            printf("| (%6.3f+%6.3fi)\n", creal(b[k]), cimag(b[k]));
        }
    }
    
    printf("\n-------- Gauss-Jordan 消元完成 --------\n");
    printf("\n最终矩阵:\n");
    for (int r = 0; r < n; r++) {
        for (int c = 0; c < n; c++) {
            printf("(%6.3f+%6.3fi) ", creal(matrix[r][c]), cimag(matrix[r][c]));
        }
        printf("| (%6.3f+%6.3fi)\n", creal(b[r]), cimag(b[r]));
    }
}


// 计算增益，返回增益的dB值
double calculate_gain(double complex Ve, double complex Vs) {

    double ve_mag = cabs(Ve);
    double vs_mag = cabs(Vs);

    double gain = vs_mag / 1;
    
    // 检查增益是否在合理范围内
    if (gain < -100.0) {
        return -100.0;  // 设置一个最小增益值（-100dB）
    }
    
    return 20 * log10(gain);
}

// 动态更新阻抗的值
void updateImpedance(double complex matrix[MAX_N][MAX_N], char types[MAX_N][MAX_N], double f, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (types[i][j] == 'L') {
                double complex Z_L = I * 2 * M_PI * f * cimag(matrix[i][j]);  // 更新电感阻抗
                matrix[i][j] = creal(matrix[i][j]) + Z_L;
            } else if (types[i][j] == 'C') {
                double complex Z_C = I * 1e3/ (2 * M_PI * f * cimag(matrix[i][j]));  // 更新电容阻抗 电容单位为mF
                matrix[i][j] = creal(matrix[i][j]) + Z_C;
            }
        }
    }
}


int main() {
    int n;
    FILE *input = fopen("in.txt", "r");
    if (input == NULL) {
        perror("无法打开文件 in.txt");
        return 1;
    }

    fscanf(input, "%d", &n);  // 读取矩阵大小
    printf("读取矩阵大小: %d\n", n);

    double complex Z[MAX_N][MAX_N];
    double complex voltages[MAX_N];
    double complex voltages_copy[MAX_N];
    double complex temp[MAX_N][MAX_N];
    char types[MAX_N][MAX_N];  // 用来存储元件类型（R, L, C）
    
    // 读取阻抗矩阵
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double re, im;
            char type;
            fscanf(input, "%lf %c %le", &re, &type, &im);
            if (type == 'C')
            {
                Z[i][j] = re / 1000 + I * im * 1e6;  //对输入数据进行缩放处理
            }
            else{
                Z[i][j] = re / 1000 + I * im;
            }
            types[i][j] = type;    // 保存元件类型（R, L, C）
            printf("读取阻抗矩阵[%d][%d]: 实部 = %lf, 虚部 = %le, 类型 = %c\n", i, j, re, im, type);
            printf("(%f+%fi) ", creal(Z[i][j]), cimag(Z[i][j]));
        }
    }

    // 读取每个回路的电压源
    for (int i = 0; i < n; i++) {
        double voltage;
        fscanf(input, "%lf", &voltage);
        voltages[i] = voltage + 0.0 * I; //电流单位为mA
        printf("读取电压源[%d]: %lf\n", i, voltage);
    }

    fclose(input);

    // 输出最后一个回路的阻抗实部并获取电阻X值
    printf("最后一个环路阻抗的实部为: %.2lf\n", 1000 * creal(Z[n-1][n-1]));
    double X;
    do {
        printf("please enter the last resistance (no more than the last real part): ");
        scanf("%lf", &X);
    } while (X / 1000 > creal(Z[n-1][n-1]));

    X /= 1000;

    // 设置初始输入电压为1V
    double complex Ve = 1.0 + 0.0 * I;

    // 打印求解后的电流值
    printf("求解后的电流向量:\n");
    for (int i = 0; i < n; i++) {
        printf("I[%d] = (%lf + %lfi)\n", i, creal(voltages[i]), cimag(voltages[i]));
    }

    // 计算增益并输出结果
    FILE *output = fopen("output.txt", "w");
    if (output == NULL) {
        perror("无法创建文件 output.txt");
        return 1;
    }

    // 在频率范围内按对数刻度逐步计算增益
    printf("开始计算Bode图...\n");
    for (double freq = 1; freq <= 1e6; freq *= 2) {
        memcpy(temp, Z, sizeof(Z));
        updateImpedance(temp, types, freq, n);
        memcpy(voltages_copy, voltages, sizeof(voltages));
        gauss_jordan(temp, voltages_copy, n);
        double complex Vs = cabs(voltages_copy[n-1] * X);  // 取X两端的电压作为Vs
        double gain_dB = calculate_gain(Ve, Vs);  // 计算增益
        fprintf(output, "%.2lf %.2lf\n", freq, gain_dB);
        printf("频率: %.2lf Hz, 增益: %.2lf dB\n", freq, gain_dB);  // 打印调试信息
    }

    fclose(output);
    printf("计算完成，结果已保存至 output.txt\n");
    return 0;
}
